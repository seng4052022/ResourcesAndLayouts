package com.seng405.ResourcesLayouts;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ConstraintLayoutActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_constraint_layout);
    }
}